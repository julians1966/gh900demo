---
title: AB-400 lab exercises
permalink: index.html
layout: home
---

The hands-on exercises for **AB-400: Extending Microsoft Power Platform solutions with code and AI**. Start with the setup guide, then take the labs in any order: each one starts from supplied files and doesn't depend on another lab.

> **Note**: To complete these exercises, you need a Microsoft Power Platform developer environment where you're an administrator, a GitHub account with GitHub Copilot, and the tools listed in the setup guide. Two labs also need an Azure subscription.

<hr>

{% assign labs = site.pages | where_exp:"page", "page.url contains '/Instructions/Labs'" %}
{% for activity in labs  %}
{% if activity.lab.title %}
### [{{ activity.lab.title }}]({{ site.github.url }}{{ activity.url }})

{% if activity.lab.level %}**Level**: {{activity.lab.level}} \| {% endif %}{% if activity.lab.duration %}**Duration**: {{activity.lab.duration}} minutes{% endif %}

{% if activity.lab.description %}
*{{activity.lab.description}}*
{% endif %}
<hr>
{% endif %}
{% endfor %}
