# AB-400: Extending Microsoft Power Platform solutions with code and AI

Lab exercises for the AB-400 course. The published exercises are at https://microsoftlearning.github.io/AB-400_Microsoft-Power-Platform-Developer/.

| Folder | Contents |
|:--|:--|
| `Instructions/Labs/` | The exercise instructions, `00-setup.md` first |
| `Allfiles/` | Files learners download or clone: the base solution (`shared/`) and each lab's starter files |
| `Build/` | Source and tooling for the supplied solutions (not published to the site) |
